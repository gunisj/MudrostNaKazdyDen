package sk.mudrostnakazdyden

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Wisdom(val theme:String, val text:String, val reflection:String)

class MainActivity : AppCompatActivity() {
    private lateinit var wisdoms: List<Wisdom>
    private lateinit var dateText: TextView
    private lateinit var themeText: TextView
    private lateinit var quoteText: TextView
    private lateinit var reflectionText: TextView
    private lateinit var favoriteButton: Button
    private var selectedDate: LocalDate = LocalDate.now()
    private val prefs by lazy { getSharedPreferences("wisdom", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wisdoms = loadWisdoms()
        createNotificationChannel()
        askNotificationPermission()
        scheduleDailyReminder()
        buildScreen()
        showDay()
    }

    private fun loadWisdoms(): List<Wisdom> {
        val raw = assets.open("wisdoms.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Wisdom(o.getString("theme"), o.getString("text"), o.getString("reflection"))
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(23,44,58))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "Múdrosť na každý deň"
            textSize = 27f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "Malá myšlienka. Nový pohľad. Každý deň."
            textSize = 14f; setTextColor(Color.rgb(211,224,231)); gravity = Gravity.CENTER
            setPadding(0,8,0,26)
        }
        root.addView(subtitle, matchWrap())
        dateText = TextView(this).apply {
            textSize=16f; setTextColor(Color.rgb(246,206,131)); gravity=Gravity.CENTER
            setPadding(0,0,0,16)
        }
        root.addView(dateText, matchWrap())
        val card = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(22,26,22,26)
            setBackgroundColor(Color.rgb(41,67,82))
        }
        themeText = TextView(this).apply {
            textSize=13f; setTextColor(Color.rgb(246,206,131)); gravity=Gravity.CENTER
        }
        card.addView(themeText, matchWrap())
        quoteText = TextView(this).apply {
            textSize=23f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            setPadding(0,20,0,18)
            typeface=android.graphics.Typeface.create("serif", android.graphics.Typeface.ITALIC)
        }
        card.addView(quoteText, matchWrap())
        val author = TextView(this).apply {
            text="Autorské múdrosti aplikácie"; textSize=12f
            setTextColor(Color.rgb(211,224,231)); gravity=Gravity.CENTER
        }
        card.addView(author, matchWrap())
        val cardParams=LinearLayout.LayoutParams(-1,0,1f)
        cardParams.topMargin=4; cardParams.bottomMargin=18
        root.addView(card, cardParams)

        val reflectionTitle=TextView(this).apply {
            text="Zamyslenie na dnes"; textSize=16f
            setTextColor(Color.rgb(246,206,131)); gravity=Gravity.CENTER
        }
        root.addView(reflectionTitle, matchWrap())
        reflectionText=TextView(this).apply {
            textSize=15f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            setPadding(8,8,8,18)
        }
        root.addView(reflectionText, matchWrap())

        favoriteButton=Button(this).apply { setOnClickListener { toggleFavorite() } }
        root.addView(favoriteButton, matchWrap())
        val share=Button(this).apply {
            text="Zdieľať dnešnú múdrosť"
            setOnClickListener {
                val w=currentWisdom()
                val text="${w.text}\n\n— Múdrosť na každý deň"
                val intent=Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,text)
                startActivity(Intent.createChooser(intent,"Zdieľať múdrosť"))
            }
        }
        root.addView(share, matchWrap())
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        nav.addView(Button(this).apply { text="‹ Predchádzajúca"; setOnClickListener { selectedDate=selectedDate.minusDays(1); showDay() } }, LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(Button(this).apply { text="Dnes"; setOnClickListener { selectedDate=LocalDate.now(); showDay() } }, LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(Button(this).apply { text="Ďalšia ›"; setOnClickListener { selectedDate=selectedDate.plusDays(1); showDay() } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(nav, matchWrap())
        val note=TextView(this).apply {
            text="365 originálnych myšlienok • obľúbené • zdieľanie • denné pripomenutie"
            textSize=11f; setTextColor(Color.rgb(185,201,210)); gravity=Gravity.CENTER
            setPadding(0,14,0,0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun matchWrap()=LinearLayout.LayoutParams(-1,-2)
    private fun currentIndex():Int = (selectedDate.dayOfYear-1).coerceIn(0,364)
    private fun currentWisdom()=wisdoms[currentIndex()]
    private fun showDay() {
        val w=currentWisdom()
        val formatter=DateTimeFormatter.ofPattern("EEEE d. MMMM yyyy", Locale.forLanguageTag("sk-SK"))
        dateText.text=selectedDate.format(formatter).replaceFirstChar { it.uppercase(Locale.forLanguageTag("sk-SK")) }
        themeText.text=w.theme.uppercase(Locale.forLanguageTag("sk-SK"))
        quoteText.text="„${w.text}“"
        reflectionText.text=w.reflection
        favoriteButton.text=if(isFavorite(currentIndex())) "★ Uložené v obľúbených" else "☆ Pridať medzi obľúbené"
    }
    private fun favoriteSet()=prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    private fun isFavorite(i:Int)=favoriteSet().contains(i.toString())
    private fun toggleFavorite() {
        val set=favoriteSet(); val key=currentIndex().toString()
        if(set.contains(key)) set.remove(key) else set.add(key)
        prefs.edit().putStringSet("favorites",set).apply()
        favoriteButton.text=if(set.contains(key)) "★ Uložené v obľúbených" else "☆ Pridať medzi obľúbené"
        Toast.makeText(this, if(set.contains(key)) "Pridané medzi obľúbené" else "Odstránené z obľúbených", Toast.LENGTH_SHORT).show()
    }
    private fun askNotificationPermission() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
    }
    private fun createNotificationChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            val channel=NotificationChannel("daily_wisdom","Denná múdrosť",NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun scheduleDailyReminder() {
        val intent=Intent(this,DailyReminderReceiver::class.java)
        val pending=PendingIntent.getBroadcast(this,1,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm=getSystemService(ALARM_SERVICE) as AlarmManager
        val cal=java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY,8); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0)
            if(timeInMillis<=System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR,1)
        }
        if(Build.VERSION.SDK_INT>=31 && !alarm.canScheduleExactAlarms()) {
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pending)
        } else {
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pending)
        }
    }
}

class DailyReminderReceiver: BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent?) {
        val raw=context.assets.open("wisdoms.json").bufferedReader().use{it.readText()}
        val arr=JSONArray(raw)
        val index=(java.time.LocalDate.now().dayOfYear-1).coerceIn(0,364)
        val quote=arr.getJSONObject(index).getString("text")
        val notification=if(Build.VERSION.SDK_INT>=26)
            Notification.Builder(context,"daily_wisdom") else Notification.Builder(context)
        val n=notification.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Múdrosť na každý deň")
            .setContentText(quote)
            .setStyle(Notification.BigTextStyle().bigText(quote))
            .setAutoCancel(true).build()
        val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT<33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)
            manager.notify(21,n)
    }
}
class BootReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent?) {
        if(intent?.action==Intent.ACTION_BOOT_COMPLETED) {
            val alarm=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi=PendingIntent.getBroadcast(context,1,Intent(context,DailyReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val cal=java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY,8); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0)
                if(timeInMillis<=System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR,1)
            }
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
        }
    }
}