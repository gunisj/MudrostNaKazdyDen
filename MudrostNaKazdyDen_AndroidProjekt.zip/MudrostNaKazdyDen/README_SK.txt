MÚDROSŤ NA KAŽDÝ DEŇ – Android projekt

Čo aplikácia obsahuje:
- 365 autorských slovenských múdrostí rozdelených do tém
- múdrosť podľa aktuálneho dátumu
- prezeranie predchádzajúcich a nasledujúcich dní
- uloženie/odstránenie obľúbenej myšlienky
- zdieľanie citátu
- denná notifikácia približne o 8:00 (po povolení upozornení)

Ako vytvoriť APK:
1. Nainštaluj Android Studio z https://developer.android.com/studio
2. Rozbaľ ZIP.
3. V Android Studio vyber Open a otvor priečinok MudrostNaKazdyDen.
4. Počkaj na Gradle Sync a prípadne povoľ doinštalovanie Android SDK 35.
5. Vyber Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK nájdeš v app/build/outputs/apk/debug/app-debug.apk
7. Prenes APK do Android telefónu, otvor ho a povoľ inštaláciu z daného zdroja.

Poznámka:
Toto je zdrojový Android Studio projekt, nie už skompilovaný APK. Na vytvorenie APK je potrebné Android Studio a Android SDK.
Denná notifikácia sa plánuje na približne 8:00. Presný čas závisí od nastavení Androidu a úspory batérie.
Všetky múdrosti sú originálne texty vytvorené pre túto aplikáciu; nie sú pripisované známym osobnostiam.
